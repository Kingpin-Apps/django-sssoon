from django.apps import AppConfig


class SssoonConfig(AppConfig):
    name = 'sssoon'
